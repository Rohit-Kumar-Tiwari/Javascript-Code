/*
import a from "./input.js"
console.log(a);
*/ 
/*
import show from "./input.js"
show(10,25)

import child from "./input.js"
var obj=new child()
obj.fun()

import {show,child} from "./input.js"
show(10,25)
var obj=new child()
obj.fun()
*/ 
import display,{data} from "./input.js";
display()
console.log(data);