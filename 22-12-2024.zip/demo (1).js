/*
class father{
    show(){
        console.log("show called-",this.a,this.b);
    }
    constructor(a,b){
        this.a=a
        this.b=b
        console.log("father constructor called");
    }
}
class child extends father{
    fun(){
        console.log("fun called");
    }
    constructor(a,b){
        super(a,b)
        console.log("child constructor called-",a,b);
    }
}
var obj=new child(50,100)
obj.show()
*/ 
class A{
    fun1(){console.log("fun1 called");}
}
class B extends A{
    fun2(){console.log("fun2 called");}
}
class C extends B{
    fun3(){console.log("fun3 called");}
}
class D extends C{
    fun4(){console.log("fun4 called ");}
}
var obj=new D()
obj.fun1()
obj.fun2()
obj.fun3()
obj.fun4()
