/*
var a=100
export default a
*/ 
/*
function show(a,b){
    console.log("show called-",a*b);
}
export default show

class child{
    fun(){
        console.log("fun called");
    }
}
export default child

function show(a,b){
    console.log("show called-",a*b);
}
class child{
    fun(){
        console.log("fun called");
    }
}
export {show,child}
*/ 

export default function display(){
    console.log("display called");
}

export let data="amit kumar"