let obj=[
{id:1,name:"sumit1",age:21,city:"noida1",pimage:"Product/m1.jpg",category:"mobile"},
{id:2,name:"sumit2",age:22,city:"noida2",pimage:"Product/m2.jpg",category:"mobile"},
{id:3,name:"sumit3",age:23,city:"noida3",pimage:"Product/s1.jpg",category:"shirt"},
{id:4,name:"sumit4",age:24,city:"noida4",pimage:"Product/s2.jpg",category:"shirt"},
{id:5,name:"sumit5",age:25,city:"noida5",pimage:"Product/w1.jpg",category:"watch"},
{id:6,name:"sumit6",age:26,city:"noida6",pimage:"Product/w2.jpg",category:"watch"},
{id:7,name:"sumit7",age:27,city:"noida7",pimage:"Product/m4.jpg",category:"mobile"}
]
var total=obj.map((item)=>{
return(`
<div>
<img src=${item.pimage} height="100px" width="150px">
<h3>Name= ${item.name} and ID=${item.id} </h3>
<p> age=${item.age} city=${item.city}</p>
</div>
`)
})
document.getElementById("root").innerHTML=total


function filterdata(cat){
var fdata=obj.filter((curcat)=>{
return cat===curcat.category
})
var total=fdata.map((item)=>{
    return(`
    <div>
    <img src=${item.pimage} height="100px" width="150px">
    <h3>Name= ${item.name} and ID=${item.id} </h3>
    <p> age=${item.age} city=${item.city}</p>
    </div>
    `)
    })
    document.getElementById("root").innerHTML=total
}