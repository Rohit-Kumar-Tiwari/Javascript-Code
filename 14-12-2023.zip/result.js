let fun=async()=>{
    let res=await fetch("https://fakestoreapi.com/products/1")
    // console.log(res.json());
    const result=await res.json()
    console.log(result);
    let totalData = result.map((item) => {
      return `
          <div class="product col-3">
              <img src="${item.pimage}" alt="${item.pname}">
              <div class="data">
                  <h2>Pname=${item.pname}</h2>
                  <p>Price=Rs-${item.price}</p>
                  <p>Category=-${item.category}</p>
                  <p>Sub-Category=-${item.subcategory}</p>
              </div>
          </div>
      `;
  });
fun()


function catfilter(cat){
var fdata=result.filter((pro)=>{
  return cat===pro.category
})
let totaldata=fdata.map((item)=>{
    return
        `
      <div class="product col-3">  
        <img src=${item.pimage}>
    <div class="data">
    <h2>Pname=${item.pname}  </h2>
    <p>Price=Rs-${item.price}  </p>
    <p>Category=-${item.category}  </p>
    <p>Sub-Category=-${item.subcategory}  </p>
    </div>
      </div>
        
        `
    
        })
        document.getElementById("myrow").innerHTML=totaldata.join('')
}



function msubcat(msub,cat){
var mdata=result.filter((pro)=>{
return msub===pro.subcategory && cat===pro.category
})
let totaldata=mdata.map((item)=>{
    return(
        `
      <div class="product col-3">  
        <img src=${item.pimage}>
    <div class="data">
    <h2>Pname=${item.pname}  </h2>
    <p>Price=Rs-${item.price}  </p>
    <p>Category=-${item.category}  </p>
    <p>Sub-Category=-${item.subcategory}  </p>
    </div>
      </div>
        
        `
    )
        })
        document.getElementById("myrow").innerHTML=totaldata.join('');
}
}