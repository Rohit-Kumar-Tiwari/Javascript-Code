async function fetchNews(category) {
  const res = await fetch(`https://newsapi.org/v2/everything?q=${category}&language=hindi&apiKey=a53f9d592bcb4b328768abfedcdcbf8b`);
  const result = await res.json();
  console.log(result);
  const news =  result.articles.map(item => `
      <div class="news col-3"> 
          <img src=${item.urlToImage}>
          <div class="content">
              <h2>${item.title}</h2>
              <p>${item.description}</p>
              <a href=${item.url}>More News</a>
          </div>
      </div>
  `);
  const div = document.getElementById('myrow');
  div.innerHTML = news
}

async function displayNews(category) {
  const totaldata = await fetchNews(category);
  document.getElementById("myrow").innerHTML = totaldata.join('');
}


window.onload = function() {
  fetchNews('all');
};
