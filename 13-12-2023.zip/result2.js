
// let fun=async()=>{
//     var res=await fetch("https://newsapi.org/v2/everything?q=all&language=hi&apiKey=14a6465a5d284669b03cf17fd0e7c1ef")
// // console.log(res.json());
// var result=await res.json();
// // console.log(result.articles);
//  var totaldata=result.articles.map((item)=>{
// // console.log(item);
// return(
//     `
//    <div class="news col-3"> 
//     <img src=${item.urlToImage}>
//     <div class="content">
// <h2>${item.title} </h2>
// <p>${item.description} </p>
// <a href=${item.url}>More News</a>
//     </div>
//     </div> tAZsdfgtujp[]
//     `
// )
//     })
//     document.getElementById("myrow").innerHTML=totaldata
// }
// fun()

// let fun1=async()=>{
//     // console.log('hello')
//     var res=await fetch("https://newsapi.org/v2/everything?q=Cricket&language=hi&apiKey=14a6465a5d284669b03cf17fd0e7c1ef")
// // console.log(res.json());
// var result=await res.json();
// // console.log(result.articles);
//  var totaldata=result.articles.map((item)=>{
// // console.log(item);
// return(
//     `
//    <div class="news col-3"> 
//     <img src=${item.urlToImage}>
//     <div class="content">
// <h2>${item.title} </h2>
// <p>${item.description} </p>
// <a href=${item.url}>More News</a>
//     </div>
//     </div>
//     `
// )
//     })
//     document.getElementById("myrow").innerHTML=totaldata;
// }

// let fun2=async()=>{
//     var res=await fetch("https://newsapi.org/v2/everything?q=Film&language=hi&apiKey=14a6465a5d284669b03cf17fd0e7c1ef")
// // console.log(res.json());
// var result=await res.json();
// // console.log(result.articles);
//  var totaldata=result.articles.map((item)=>{
// // console.log(item);
// return(
//     `
//    <div class="news col-3"> 
//     <img src=${item.urlToImage}>
//     <div class="content">
// <h2>${item.title} </h2>
// <p>${item.description} </p>
// <a href=${item.url}>More News</a>
//     </div>
//     </div>
//     `
// )
//     })
//     document.getElementById("myrow").innerHTML=totaldata
// }

// let fun3=async()=>{
//     var res=await fetch("https://newsapi.org/v2/everything?q=Money&language=hi&apiKey=14a6465a5d284669b03cf17fd0e7c1ef")
// // console.log(res.json());
// var result=await res.json();
// // console.log(result.articles);
//  var totaldata=result.articles.map((item)=>{
// // console.log(item);
// return(
//     `
//    <div class="news col-3"> 
//     <img src=${item.urlToImage}>
//     <div class="content">
// <h2>${item.title} </h2>
// <p>${item.description} </p>
// <a href=${item.url}>More News</a>
//     </div>
//     </div>
//     `
// )
//     })
//     document.getElementById("myrow").innerHTML=totaldata
// }


// let fun4=async()=>{
//     var res=await fetch("https://newsapi.org/v2/everything?q=Politics&language=hi&apiKey=14a6465a5d284669b03cf17fd0e7c1ef")
// // console.log(res.json());
// var result=await res.json();
// // console.log(result.articles);
//  var totaldata=result.articles.map((item)=>{
// // console.log(item);
// return(
//     `
//    <div class="news col-3"> 
//     <img src=${item.urlToImage}>
//     <div class="content">
// <h2>${item.title} </h2>
// <p>${item.description} </p>
// <a href=${item.url}>More News</a>
//     </div>
//     </div>
//     `
// )
//     })
//     document.getElementById("myrow").innerHTML=totaldata
// }











let fun=async(cat)=>{
     var res=await fetch(`https://newsapi.org/v2/everything?q=${cat}&language=Hindi&apiKey=14a6465a5d284669b03cf17fd0e7c1ef`)
 console.log(res.json());
var result=await res.json();
// console.log(result.articles);
 var totaldata=result.articles.map((item)=>{
// console.log(item);
return(
    `
   <div class="news col-3"> 
    <img src=${item.urlToImage}>
    <div class="content">
<h2>${item.title} </h2>
<p>${item.description} </p>
<a href=${item.url}>More News</a>
    </div>
    </div>
    `
)
    })
    document.getElementById("myrow").innerHTML=totaldata.join('')
}

// async function getData() {
//     try {
//         var res = await fetch(`https://newsapi.org/v2/everything?q=all&language=hi&apiKey=a53f9d592bcb4b328768abfedcdcbf8b`)
//         res.json().then((result) => {
//             console.log(result);
//             var data = result.articles
//             var totaldata = data.map((item) => {
//                 return (
//                     `
// <div class="left col-3">
// <img src=${item.urlToImage} height="170px" >
// <h2>${item.title}</h2>
// <p> ${item.description} </p>
// <a href=${item.url}><button>More New</button></a>
//     </div>
//     `
//                 )
//             })
//             document.getElementById("root").innerHTML = totaldata.join('');
//         })
//     }
//     catch (err) {
//         console.log(err);
//     }
// }
// getData()



