/*
var obj=[
{id:1,Pname:"Mobile",price:19000,Pimage:"m1.jpg"},
{id:2,Pname:"Shirt",price:900,Pimage:"s1.jpg"},
{id:3,Pname:"Shirt",price:1200,Pimage:"s2.jpg"},
{id:4,Pname:"Watch",price:12000,Pimage:"w1.jpg"},
{id:5,Pname:"Watch",price:14000,Pimage:"w4.jpg"}
]
for(var i=0;i<obj.length;i++){
    document.write(`
<div>
<img src=${obj[i].Pimage}>
<h2> Product name=${obj[i].Pname}  </h2>
<p> Id=${obj[i].id} price=Rs.${obj[i].price} </p>


<div>
    `)
}

1- function with no argument and not return value 
2- function with  argument and not return value 
3- function with  argument and with return value 
4- function with no argument and with return value 


function_name()
function function_name(){
    statement 
}

function_name()

data()
function data(){
    console.log("data called");
}

data()

function show(a,b){
console.log("show called-",a+b);
}
show(10,50)
show(70,80)

function display(a,b,c){
    console.log("display called-",a,b,c,arguments[3],arguments[4]);
    // console.log(arguments);
    
}
display(10,20,30,40,50)

function data(x,y,...rest){
console.log(x,y);
// console.log(rest);
console.log(rest[0],rest[1],rest[2],rest[3]);
}
data(10,50,60,70,80,90)
 
function getdata(a,b,c=100){
console.log(a+b+c);
}
getdata(10,20)
getdata(10,20,50)

function child(x,y){
  return x*y 
}
// console.log(child(50,10));
 var result= child(10,30)
 console.log(result);

function data(){
    var a=10
    var b=20
    var c=a+b 
    return c 
}
// console.log(data());
var result=data()
console.log(result);
 */
